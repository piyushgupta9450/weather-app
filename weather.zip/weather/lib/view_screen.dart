import 'package:flutter/material.dart';
import 'package:weather/model/weather.dart';
import 'package:intl/intl.dart';

class ViewScreen extends StatefulWidget {
  final Weather weather;
  final Function callBack;

  ViewScreen({this.weather, this.callBack});

  @override
  _ViewScreenState createState() => _ViewScreenState();
}

class _ViewScreenState extends State<ViewScreen> {
  TextEditingController _cityController = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.purple,
      body: Center(child: _buildWeather()),
    );
  }

  _buildWeather() {
    var today = widget.weather.location.localtime;
    DateTime dateTime = DateTime.parse(today);
    String day = DateFormat('EEEE').format(dateTime);
    String timeOfDay = DateFormat("h:mma").format(dateTime);

    return SingleChildScrollView(
      child: Container(
        // padding: EdgeInsets.only(left: 40),
        child: Column(
          // crossAxisAlignment: CrossAxisAlignment.start,
          children: <Widget>[
            Container(
              padding: EdgeInsets.only(right: 200),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: <Widget>[
                  Text(day,
                      style: TextStyle(fontSize: 35, color: Colors.white, fontWeight: FontWeight.normal)),
              Text(timeOfDay,
                  style: TextStyle(fontSize: 45, color: Colors.white, fontWeight: FontWeight.bold,letterSpacing: 1)),
                ],
              ),
            ),
            SizedBox(height: 80.0),
            Container(
                padding: EdgeInsets.only(left: 100),
                height: 150,
                width: 150,
                decoration: new BoxDecoration(
                  shape: BoxShape.circle,
                  image: new DecorationImage(
                    image: widget.weather.current.weatherIcons[0] != null
                        ? new NetworkImage(widget.weather.current.weatherIcons[0])
                        : ExactAssetImage('images/profile_image.png'),
                    fit: BoxFit.cover,
                  ),
                )),
            SizedBox(height: 120.0),
            Container(
              padding: EdgeInsets.only(left: 20),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceAround,
                crossAxisAlignment: CrossAxisAlignment.center,
                children: <Widget>[
                  Text('${widget.weather.current.temperature.toString()}°c',
                      style: TextStyle(fontSize: 65, color: Colors.white)),
                  // VerticalDivider(
                  //   color: Colors.white,
                  //   thickness: 2,
                  //   width: 20,
                  //   indent: 10,
                  //   endIndent: 10,
                  // ),
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: <Widget>[
                      Container(
                        width: 190,
                        // color: Colors.blue,
                        child: Text(widget.weather.current.weatherDescriptions[0],
                            maxLines: 3,
                            overflow: TextOverflow.ellipsis,
                            style: TextStyle(
                                fontSize: 25, color: Colors.white, fontWeight: FontWeight.bold)),
                      ),
                      SizedBox(height: 10.0),
                      Text("${widget.weather.request.query}",
                          style: TextStyle(
                              fontSize: 20, color: Colors.white, fontWeight: FontWeight.normal))
                    ],
                  )
                ],
              ),
            ),
            SizedBox(height: 100.0),
            Container(
              width: 290,
              child: TextFormField(
                // autofocus: true,
                style: TextStyle(fontSize: 20, color: Colors.black),
                controller: _cityController,
                decoration: InputDecoration(
                    fillColor: Colors.white,
                    filled: true,
                    hintText: "Enter city name",
                    contentPadding: new EdgeInsets.symmetric(vertical: 10.5, horizontal: 20),
                    focusedBorder: OutlineInputBorder(
                      borderSide: BorderSide(color: Colors.grey),
                      borderRadius: BorderRadius.circular(1),
                    ),
                    enabledBorder: OutlineInputBorder(
                      borderSide: BorderSide(color: Colors.grey),
                      borderRadius: BorderRadius.circular(1),
                    )),
                onChanged: (value) => setState(() {
                  _cityController.selection =
                      TextSelection.fromPosition(TextPosition(offset: value.length));
                }),
              ),
            ),
            SizedBox(height: 20.0),
            Container(
              height: 50,
              width: 100,
              color: Colors.white,
              child: FlatButton(
                child: Text('Submit'),
                onPressed: () =>
                    {widget.callBack(_cityController.text), FocusScope.of(context).unfocus()},
              ),
            ),
            SizedBox(height: 20.0),
          ],
        ),
      ),
    );
  }
}
