import 'package:flutter/material.dart';

class ErrorScreen extends StatelessWidget {
  final Function callBack;
  ErrorScreen({this.callBack});
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.purple,
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: <Widget>[
            Text('Invalid City Name',
                style: TextStyle(fontSize: 28, color: Colors.white, fontWeight: FontWeight.bold)),
            SizedBox(height: 15.0),
            Container(
              height: 50,
              width: 100,
              color: Colors.white,
              child: FlatButton(
                child: Text('Retry'),
                onPressed: () => {callBack('Kolkata')},
              ),
            ),
          ],
        ),
      ),
    );
  }
}
