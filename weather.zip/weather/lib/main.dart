import 'package:flutter/material.dart';

import 'package:provider/provider.dart' as prefix;

import 'landing_screen.dart';
import 'provider/app_provider.dart';

void main() {
  runApp(WeatherApp());
}

class WeatherApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return prefix.Provider<AppProvider>(
        create: (_) => AppProvider(),
        child: MaterialApp(
          title: 'Flutter Demo',
          home: LandingScreen(),
        ));
  }
}
