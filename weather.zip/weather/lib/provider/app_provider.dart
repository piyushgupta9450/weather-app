import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:basic_utils/basic_utils.dart';
import 'package:weather/model/weather.dart';

class AppProvider extends ChangeNotifier {
  Future<Weather> getWeather(String searchKey) async {
    final url = 'http://api.weatherstack.com/forecast';
 

    Map<String, dynamic> queryParams = {
      'access_key': 'a3fd7937c2b651f30024b0cf5a7a3cfe',
      'query': searchKey
    };
     Weather weather; 
    final http.Response response =
        await HttpUtils.getForFullResponse(url, queryParameters: queryParams);

    if (response != null) {
       Map<String, dynamic> jsonData = json.decode(response.body);
       weather = Weather.fromJson(jsonData);

      // jsonList.forEach((element) {
      // miniMarketList.add(MiniMarket.fromJson(element));
      // });
    }
    return weather;
  }
}
