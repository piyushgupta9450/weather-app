import 'package:flutter/material.dart';
import 'package:weather/model/weather.dart';
import 'package:weather/view_screen.dart';

import 'error_screen.dart';
import 'provider/app_provider.dart';

class LandingScreen extends StatefulWidget {
  @override
  _LandingScreenState createState() => _LandingScreenState();
}

class _LandingScreenState extends State<LandingScreen> {
  String searchCity = 'Kolkata';

  @override
  Widget build(BuildContext context) {
    return FutureBuilder(
      future: AppProvider().getWeather(searchCity),
      builder: (context, snapshot) {
        if (snapshot.hasError) {
          return Container();
        } else if (snapshot.hasData) {
          Weather weather = snapshot.data;
          return weather.current == null
              ? ErrorScreen(
                  callBack: (String val) {
                    setState(() {
                      searchCity = val;
                    });
                  },
                )
              : ViewScreen(
                  weather: weather,
                  callBack: (String val) {
                    setState(() {
                      searchCity = val;
                    });
                  },
                );
        } else
          return Container();
      },
    );
  }
}
